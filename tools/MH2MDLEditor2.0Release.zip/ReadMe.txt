﻿Manhunt2 MDL Editor
==================================================

This tool is an Manhunt2 *.MDL/*.DFF models file Editor.

Includes the following functions:

Add (include merge big/multi mdl/dff file ,add single mdl/dff file)
Delete (single/Multiple)
Export (single/Multiple mdl/dff file)
Replace (single mdl/dff file)
Reorder
Save/SaveAs
Decompress/Compress zlib resource file.

Requirement
------------
.NET framework 4.0 or Higher

Information
-----------
Program Name: Manhunt 2 MDL Editor
Revision
 Version: v2.0 Release Date: Sep  03, 2018
First Version: v1.0 Release Date: December 1, 2013

Author information
------------------

 Written by Allen
 E-mail: Leeao@live.com

 Find Me:
 gtaforums.com

Changelogs
-----------
2018-09-03 Release Version 2.0
-Add "Reorder by name" function
-Add multiple export and multiple delete function
-Add multiple add function
-Add Right click menu (context menu)
-Simplify the program, Include DLL into EXE

2015-10-15 Release Version 1.85
-Fixed old version Manhunt2 MDL Editor created or saved files compatibility issues.

2015-10-10 Release Version 1.8
-Fixed a model invisible/popping bug.
-Optimize the textures name part of the code
.

2015-10-1 Release Version1.7
-Added WII DFF version model edit
-Added an WII DFF to PC MDL Format Converter

2014-2-22 Release Version1.6
-Fixed Save PS2 DFF file size error!

2014-2-17 Release Version1.5
-Add PS2/PSP Version DFF format editor support
-Add Compress/Decompress Z2HM File,MDL File Support

2013-12-2 Release Version1.1
-Add Rename function

2013-12-1 Release Version1.0
-Includes the following functions:
-Add(include merge big/multi mdl file ,add single mdl file)
-Delete
-Export(single mdl file)
-Replace(single mdl file)
-Save/SaveAs

If you have questions, or report a bug, please send me an email!

Allen