﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gtacol2mh
{
    class Datatype
    {
        public struct TVector
        {
            public float X;
            public float Y;
            public float Z;
        }
        public struct TBounds
        {
            public TVector center;
            public float radius;
            public TVector min;
            public TVector max;
        }
        public struct TSurface
        {
            public byte material;
            public byte flag;
            public byte brightness;
            public byte light;
        }
        public struct Lines
        {
            public TVector point1;
            public TVector point2;
        }

        public struct TBox
        {
            public TVector min;
            public TVector max;
            public TSurface surface;
        }
        public struct TVertex
        {
            public TVector XYZ;
        }
        public struct TSphere
        {
            public float radius;
            public TVector center;
            public TSurface surface;
        }

        public struct TFace
        {
            public uint[] VertID;// x y z uint[3]
            public TSurface surface;
        }
    }
}
