﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Text;
namespace gtacol2mh
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length>0)
            {
                string ext = Path.GetExtension(args[0]).ToLower();
                if (ext != ".col")
                {
                    Console.WriteLine("Can't support this file:" + args[0]);
                    return;
                }
                else
                {
                    if (File.Exists(args[0]))
                    {
                        string openFileName = args[0];
                        FileStream check = new FileStream(openFileName, FileMode.Open, FileAccess.Read);
                        byte[] magicbytes = new byte[4];
                        int read = check.Read(magicbytes, 0, 4);
                        string magic = Encoding.ASCII.GetString(magicbytes);
                        if (magic != "COLL")
                        {
                            check.Close(); check.Dispose();

                        }
                        else
                        {
                            MHCOL col = new MHCOL();
                            col.OutCol(args[0]);
                        }
                    }
                }
            }
            else
            {
                Application.Run(new Form1());
            }

           
        }
    }
}
