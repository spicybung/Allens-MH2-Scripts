﻿using System.Collections.Generic;
using System.IO;
using System.Text;
namespace gtacol2mh
{
    class GTACOL
    {

        public class GTACOL1
        {
            public string FourCC;//COLL
            public uint  DataSize;
            public string colName;
            public ushort modelID;
            public Datatype.TBounds bounds;
            public uint numSpheres;
            public Datatype.TSphere[] spheres;
            public int unused;
            public uint numBoxes;
            public Datatype.TBox[] boxes;
            public uint numVertex;
            public Datatype.TVertex[] vertices;
            public uint numFaces;
            public Datatype.TFace[] faces;
        }
        public Datatype.TVector ReadVector(BinaryReader br)
        {
            Datatype.TVector v = new Datatype.TVector();
            v.X = br.ReadSingle();
            v.Y = br.ReadSingle();
            v.Z = br.ReadSingle();
            return v;
        }
        public Datatype.TBounds ReadBounds(BinaryReader br)
        {
            Datatype.TBounds bound = new Datatype.TBounds();
            bound.radius = br.ReadSingle();
            bound.center = ReadVector(br);
            bound.min = ReadVector(br);
            bound.max = ReadVector(br);
            return bound;
        }
        public Datatype.TSurface ReadSurface(BinaryReader br)
        {
            Datatype.TSurface surface = new Datatype.TSurface();
            surface.material = br.ReadByte();
            surface.flag = br.ReadByte();
            surface.brightness = br.ReadByte();
            surface.light = br.ReadByte();
            return surface;        
        }
        public Datatype.TSphere ReadSphere(BinaryReader br)
        {
            Datatype.TSphere sphere = new Datatype.TSphere();
            sphere.radius = br.ReadSingle();
            sphere.center = ReadVector(br);
            sphere.surface = ReadSurface(br);
            return sphere;
        }
        public Datatype.TBox ReadBox(BinaryReader br)
        {
            Datatype.TBox box = new Datatype.TBox();
            box.min = ReadVector(br);
            box.max = ReadVector(br);
            box.surface = ReadSurface(br);
            return box;
        }
        public Datatype.TFace ReadFace(BinaryReader br)
        {
            Datatype.TFace face = new Datatype.TFace();
            face.VertID = new uint[3];
            face.VertID[0] = br.ReadUInt32();
            face.VertID[1] = br.ReadUInt32();
            face.VertID[2] = br.ReadUInt32();
            face.surface = ReadSurface(br);
            return face;

        }
        public Datatype.TVertex ReadVertex(BinaryReader br)
        {
            Datatype.TVertex vertex = new Datatype.TVertex();
            vertex.XYZ = ReadVector(br);
            return vertex;
        }
        public string ReadCOLString(BinaryReader br)
        {
            long endofs = br.BaseStream.Position + 22;
            string str = br.ReadString();
            br.BaseStream.Seek(endofs, SeekOrigin.Begin);
            return str;
        }
        public string ReadString(BinaryReader br)
        {
            long endofs = br.BaseStream.Position + 22;
            string str = "";
            bool loop = true;
            do
            {
                byte[] temp = br.ReadBytes(1);
                if (temp[0] != 0)
                {
                    str += Encoding.ASCII.GetString(temp);
                }
                else
                {
                    loop = false;
                }
            } while (loop);
            br.BaseStream.Seek(endofs, SeekOrigin.Begin);
            return str;
        }
        public List<GTACOL1> GTACOLModels;
        public GTACOL1 ReadGTACOL1(BinaryReader br)
        {
            GTACOL1 col = new GTACOL1();
            col.FourCC = Encoding.ASCII.GetString(br.ReadBytes(4));
            col.DataSize = br.ReadUInt32();
            col.colName = ReadString(br);
            col.modelID = br.ReadUInt16();
            col.bounds = ReadBounds(br);
            col.numSpheres = br.ReadUInt32();
            if (col.numSpheres > 0)
            {
                col.spheres = new Datatype.TSphere[col.numSpheres];
                for (int i = 0; i < col.numSpheres; i++)
                {
                    col.spheres[i] = ReadSphere(br);
                }
            }

            col.unused = br.ReadInt32();
            col.numBoxes = br.ReadUInt32();
            if (col.numBoxes > 0)
            {
                col.boxes = new Datatype.TBox[col.numBoxes];
                for (int i = 0; i < col.numBoxes; i++)
                {
                    col.boxes[i] = ReadBox(br);
                }
            }
            col.numVertex = br.ReadUInt32();
            if (col.numVertex > 0)
            {
                col.vertices = new Datatype.TVertex[col.numVertex];
                for (int i = 0; i < col.numVertex; i++)
                {
                    col.vertices[i] = ReadVertex(br);
                }
            }
            col.numFaces = br.ReadUInt32();
            if (col.numFaces > 0)
            {
                col.faces = new Datatype.TFace[col.numFaces];
                for (int i=0;i<col.numFaces;i++)
                {
                    col.faces[i] = ReadFace(br);
                }
            }
            return col;
        }
        public List<GTACOL1> ReadCOLList(BinaryReader br)
        {
            GTACOLModels = new List<GTACOL1>();
            long FileSize = br.BaseStream.Length;
            while (br.BaseStream.Position < FileSize)
            {
                GTACOLModels.Add(ReadGTACOL1(br));
            }
            return GTACOLModels;            
        }
    }
}
