﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
namespace gtacol2mh
{
    class MHCOL
    {

        public struct MHSphere{
            public Datatype.TVector center;
            public float radius;
            public Datatype.TSurface surface;
        }

        public struct MHFace
        {
            public uint[] VertID;// x y z uint[3]
        };
        public class TModel
        {
            public string name;
            public Datatype.TBounds bounds;
            public uint numSpheres;
            public MHSphere[] spheres;
            public uint numLines;
            public Datatype.Lines[] lines;
            public uint numBoxes;
            public Datatype.TBox[] boxes;
            public uint numVertex;
            public Datatype.TVertex[] vertices;
            public uint numFaces;
            public MHFace[] faces;
        }
        public List<TModel> MHCOLModels;
        public List<TModel> GTACOL1toMH (GTACOL gtacolList)
        {
            MHCOLModels = new List<TModel>();
            for (int i=0;i<gtacolList.GTACOLModels.Count();i++)
            {
                GTACOL.GTACOL1 col1 = gtacolList.GTACOLModels[i];
                TModel mhcol = new TModel();
                mhcol.name = col1.colName;
                mhcol.bounds = col1.bounds;
                mhcol.numSpheres = col1.numSpheres;
                if (mhcol.numSpheres>0)
                {
                    mhcol.spheres = new MHSphere[mhcol.numSpheres];
                    for (int j=0;j<mhcol.numSpheres;j++)
                    {                        
                        mhcol.spheres[j].center = col1.spheres[j].center;
                        mhcol.spheres[j].radius = col1.spheres[j].radius;
                        mhcol.spheres[j].surface = col1.spheres[j].surface;
                    }
                }
                mhcol.numLines = 0;
                mhcol.numBoxes = 0;//manhunt 1/2 unused
                mhcol.numVertex = col1.numVertex;
                if (mhcol.numVertex>0)
                {
                    mhcol.vertices = new Datatype.TVertex[mhcol.numVertex];
                    for(int j=0;j<mhcol.numVertex;j++)
                    {
                        mhcol.vertices[j] = col1.vertices[j];
                    }
                }
                mhcol.numFaces = col1.numFaces;
                if (mhcol.numFaces>0)
                {
                    mhcol.faces = new MHFace[mhcol.numFaces];
                    for (int j =0;j<mhcol.numFaces;j++)
                    {
                        mhcol.faces[j].VertID = col1.faces[j].VertID;
                    }
                }
                MHCOLModels.Add(mhcol);
            }
            return MHCOLModels;
        }
        public void WritePadding(BinaryWriter bw)
        {
            long padLen = (4 - (bw.BaseStream.Position % 4));
            if ((padLen > 0) && (padLen < 4))
            {
                for (int i=0;i<padLen;i++)
                {
                    byte pad = (byte)'p';
                    bw.Write(pad);
                }                
            }
        }
        public void WriteVector(BinaryWriter bw,Datatype.TVector vec)
        {
            bw.Write(vec.X);
            bw.Write(vec.Y);
            bw.Write(vec.Z);
        }
        public void WriteBound(BinaryWriter bw,Datatype.TBounds bound)
        {
            WriteVector(bw, bound.center);
            bw.Write(bound.radius);
            WriteVector(bw, bound.min);
            WriteVector(bw, bound.max);
        }
        public void WriteSphere(BinaryWriter bw,MHSphere sp)
        {
            WriteVector(bw, sp.center);
            bw.Write(sp.radius);
            bw.Write(0);//surface unused
        }
        public void WriteFace(BinaryWriter bw,MHFace face)
        {
            bw.Write(face.VertID[0]);
            bw.Write(face.VertID[1]);
            bw.Write(face.VertID[2]);
        }
        public void WriteString(BinaryWriter bw,string str)
        {
            bw.Write(ASCIIEncoding.ASCII.GetBytes(str));
            bw.Write((byte)(0));
        }
        public void WriteMHCOL(BinaryWriter bw,List<TModel> List)
        {
            bw.Write(List.Count);
            for (int i = 0; i < List.Count;i++)
            {
                TModel col = List[i];
                WriteString(bw, col.name);
                WritePadding(bw);
                WriteBound(bw, col.bounds);
                bw.Write(col.numSpheres);
                if (col.numSpheres > 0)
                {
                    for(int j =0;j < col.numSpheres;j++)
                    {
                        WriteSphere(bw, col.spheres[j]);
                    }
                }
                bw.Write(col.numLines);
                bw.Write(col.numBoxes);
                bw.Write(col.numVertex);
                if (col.numVertex>0)
                {
                    for (int j =0;j < col.numVertex;j++)
                    {
                        WriteVector(bw, col.vertices[j].XYZ);
                    }
                }
                bw.Write(col.numFaces);
                if (col.numFaces>0)
                {
                    for (int j=0;j<col.numFaces;j++)
                    {
                        WriteFace(bw,col.faces[j]);
                    }
                }
            }
        }
        public void OutCol(string openFileName)
        {
            FileStream colin = new FileStream(openFileName, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(colin);
            GTACOL colList = new GTACOL();
            colList.GTACOLModels = colList.ReadCOLList(br);
            colin.Close(); br.Close();
            string outColName = Path.GetDirectoryName(openFileName) + "\\" + Path.GetFileNameWithoutExtension(openFileName) + "_mh.col";
            MHCOL mhcolList = new MHCOL();
            mhcolList.MHCOLModels = mhcolList.GTACOL1toMH(colList);
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);
            mhcolList.WriteMHCOL(bw, mhcolList.MHCOLModels);
            bw.Close();
            byte[] colData = ms.ToArray();
            ms.Close();
            FileStream outcol = new FileStream(outColName, FileMode.Create, FileAccess.Write);
            outcol.Write(colData, 0, colData.Length);
            outcol.Close();
        }
    }
}
