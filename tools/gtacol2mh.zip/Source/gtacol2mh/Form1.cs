﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace gtacol2mh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string openFileName = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Select file support mutil select";
            openFileDialog1.Filter = "GTA COL Files (*.col)|*.col";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Multiselect = true;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                for (int j = 0; j < openFileDialog1.FileNames.Count();j++)
                {
                    openFileName = openFileDialog1.FileNames[j];
                    FileStream check = new FileStream(openFileName, FileMode.Open, FileAccess.Read);
                    byte[] magicbytes = new byte[4];
                    int read = check.Read(magicbytes, 0, 4);
                    string magic = ASCIIEncoding.ASCII.GetString(magicbytes);
                    if (magic != "COLL")
                    {
                        check.Close(); check.Dispose();
                        //MessageBox.Show("Can't support this file!", "Open Error");
                        this.richTextBox1.Text+= "Open Error: " + openFileName+ " Can't support this file!\n";
                    }
                    else
                    {
                        MHCOL col = new MHCOL();
                        col.OutCol(openFileName);
                        this.richTextBox1.Text += "Successfully converted: " + openFileName + "\n";
                    }
                }

            }
            else
            {
                return;
            }

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Author: Allen.\n" +
            "Support GTA COL1 version to manhunt1 / 2\n" +
            "Support drag and drop, direct conversion(single file only), no need to open this program.\n" +
            "The form can support multiple selection files.");
        }
    }
}
