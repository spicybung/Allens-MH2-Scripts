This is a tools for convert gta col1 collision format to manhunt 1/2 col format.

By Allen
Nov,2 2019